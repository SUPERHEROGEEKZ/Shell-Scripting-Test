/*                                                                                                              
 * Filename header.h                                                                                           
 * Date September 3, 2020                                                                                      
 * Author Zainab Anwar                                                                                          
 * Email zxa180005@utdallas.edu                                                                                 
 * Course CS 3377.002 Fall 2020                                                                                 
 * Version 1.0                                                                             
 * Copyright 2020, All Rights Reserved                                                                          
 *                                                                                                              
 * Description                                                                                                  
 *                                                                                                              
 * This header file links to main file1 and function file2. 
 */
#ifndef _HEADER_
#define _HEADER_

void file2();

#endif
