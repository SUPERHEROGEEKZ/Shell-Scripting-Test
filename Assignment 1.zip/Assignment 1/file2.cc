/*                                                                                                              
 * Filename file2.cc                                                                                            
 * Date September 3, 2020                                                                                       
 * Author Zainab Anwar                                                                                          
 * Email zxa180005@utdallas.edu                                                                                 
 * Course CS 3377.002 Fall 2020                                                                                 
 * Version 1.0                                                                             
 * Copyright 2020, All Rights Reserved                                                                          
 *                                                                                                              
 * Description                                                                                                  
 *                                                                                                              
 * This function source file, displays a log message that states that
 * it is inside the procedure.                                                                                  
 */

#include <iostream>
#include "header.h"

using namespace std;

void file2()
{
  cerr << "Inside proc1() as stderr\n" << endl;
  return;
}
