#!/bin/bash
                                                                                                             
# Filename compile.sh                                                                                          
# Date September 3, 2020                                                                                      
# Author Zainab Anwar                                                                                          
# Email zxa180005@utdallas.edu                                                                                
# Course CS 3377.002 Fall 2020                                                                                 
# Version 1.0                                                                             
# Copyright 2020, All Rights Reserved                                                                          
#                                                                                                              
# Description                                                                                                  
#                                                                                                              
# This shell script first sets the environment variable to scratch,
# and then compiles both file1.cc and file2.cc into output source files separately,
# then links both of those files to create hw1 which is an executable file. 

echo "Setting TEMPDIR environment variable to /scratch"
TMPDIR=/scratch;export TMPDIR

echo "Compiling file1.cc"
g++ -c file1.cc

echo "Compiling file2.cc"
g++ -c file2.cc

echo "Linking files to create executable hw1"
g++ -o hw1 file1.o file2.o

echo "Done"
