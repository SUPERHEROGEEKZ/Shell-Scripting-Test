#!/bin/bash
                                                                                                              
# Filename run.sh                                                                                            
# Date September 3, 2020                                                                                       
# Author Zainab Anwar                                                                                          
# Email zxa180005@utdallas.edu                                                                                 
# Course CS 3377.002 Fall 2020                                                                                 
# Version 1.0                                                                             
# Copyright 2020, All Rights Reserved                                                                          
#                                                                                                              
# Description                                                                                                  
#                                                                                                              
# This shell script file runs the executable file called hw1,
# and gets the number of arguments while appending them to two log files
# called stdout.log and stderr.log.                                                                                        

echo "Running 'hw1' with 0 arguments: "
echo "     stdout appended to stdout.log"
echo "     stderr appended to stderr.log"

echo "Running 'hw1' with 1 argument: "
echo "     stdout appended to stdout.log"
echo "     stderr appended to stderr.log"

echo "Running 'hw1' with 5 arguments: "
echo "     stdout appended to stdout.log"
echo "     stderr appended to stderr.log"

./hw1 >> stdout.log 2>> stderr.log

./hw1 abc >> stdout.log 2>> stderr.log

./hw1 \ a \ b \ c \ d \ e >> stdout.log 2>> stderr.log
