/*                                                                                                              
 * Filename file1.cc                                                                                       
 * Date September 3, 2020                                                                                       
 * Author Zainab Anwar                                                                                          
 * Email zxa180005@utdallas.edu                                                                                 
 * Course CS 3377.002 Fall 2020                                                                                 
 * Version 1.0                                                                             
 * Copyright 2020, All Rights Reserved                                                                          
 *                                                                                                              
 * Description                                                                                                  
 *                                                                                                              
 * This main source file prints out the number of command line arguments,
 * and also displays the value of each command line, then it calls the procedure
 * in file2, which is the function file.                                                                       
 */

#include <iostream>
#include "header.h"

using namespace std;

int main(int argc, char*argv[])

{
  cout << "argc was: " <<  argc << endl;
  for(int i=0; i < argc; i++)
    {
      cout << argv[i] << endl;
    }
  cout << "Done!" << endl;
  file2();
  return 0;
}
